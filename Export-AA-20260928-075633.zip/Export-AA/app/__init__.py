"""Local assistant prototype."""
